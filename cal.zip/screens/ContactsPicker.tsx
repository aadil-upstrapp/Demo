import React, {useEffect, useState, useRef} from 'react';
import {
  PermissionsAndroid,
  StyleSheet,
  View,
  Text,
  Button,
  SafeAreaView,
  FlatList,
  Image,
  TextInput,
  SectionList,
} from 'react-native';
import Contacts from 'react-native-contacts';
import {TouchableWithoutFeedback} from 'react-native-gesture-handler';
// import {Contact} from '.';

const requestCameraPermission = async () => {
  console.log('try');

  try {
    const granted = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.READ_CONTACTS,
      {
        title: 'Cool Photo App Camera Permission',
        message:
          'Cool Photo App needs access to your camera ' +
          'so you can take awesome pictures.',
        buttonNeutral: 'Ask Me Later',
        buttonNegative: 'Cancel',
        buttonPositive: 'OK',
      },
    );
    if (granted === PermissionsAndroid.RESULTS.GRANTED) {
      console.log('You can use the camera');
      // console.log('contacts',granted);
      // setContact()
    } else {
      console.log('Camera permission denied');
    }
  } catch (err) {
    console.warn(err);
  }
};
const ContactsPicker: React.FC = () => {
  const [contactSearch, setContactSearch] = useState('');
  const [contact, setContact] = useState([]);
  const [dataContact, setDataContact] = useState();
  const [lastText, setLastText] = useState('');
  const [inputShow, setInputShow] = useState(false);
  const [sortList, setSortList] = useState([]);
  const [selectIndex, setSelectIndex] = useState('');

  useEffect(() => {
    Contacts.getAll().then(contacts => {
      console.log('line 1');
      contacts.forEach(item => (item.color = generateColor()));
      sortData(contacts);
      // console.log(contacts);
      setContact(contacts);
      setDataContact(contacts);
      console.log('line 4');
    });
  }, []);

  useEffect(() => {
    let grouping = contact?.reduce((r, e) => {
      // get first letter of name of current element
      let title = e.displayName[0];
      // if there is no property in accumulator with this letter create it
      if (!r[title]) r[title] = {title, data: [e]};
      // if there is push current element to data array for that letter
      else r[title].data.push(e);
      // return accumulator
      return r;
    }, {});
    if (grouping) {
      grouping = Object.values(grouping);
      console.log('grouping', JSON.stringify(grouping));
      setSortList(grouping);
    }
  }, [contact]);

  /* useEffect(() => {
    console.log('sortList---', JSON.stringify(sortList));
  }, [sortList]); */

  useEffect(() => {
    console.log('line 2');
    search();
  }, [contactSearch]);

  const ref = useRef<SectionList>();

  const search = () => {
    // console.log('sortList1',sortList)
    console.log('line 3');
    // if (contactSearch) {
    if (contactSearch) {
      console.log(contactSearch, lastText);

      const a = contactSearch.toLowerCase().split(' ');
      const arr = contactSearch.startsWith(lastText) ? contact : dataContact;
      setContact(
        arr.filter(item =>
          a.every(v =>
            item.displayName
              .toLowerCase()
              .split(' ')
              .some(i => i.startsWith(v)),
          ),
        ),
      );
    } else {
      setContact(dataContact);
    }
    setLastText(contactSearch);
  };

  // setSortList(grouping);

  function sortData(myArguments) {
    console.log('Line 2');
    myArguments.sort(function (a, b) {
      /* console.log(
        'a.displayName < b.displayName',
        a.displayName.startsWith('A'),
        b.displayName,
      ); */

      if (a.displayName.includes('9') < b.displayName.includes('9')) {
        return -1;
      }
      if (a.displayName.includes('9') > b.displayName.includes('9')) {
        return 1;
      }
      if (a.displayName < b.displayName) {
        return -1;
      }
      if (a.displayName > b.displayName) {
        return 1;
      }
      return 0;
    });
  }
  const generateColor = () => {
    const randomColor = Math.floor(Math.random() * 16777215)
      .toString(16)
      .padStart(6, '0');
    return `#${randomColor}`;
  };
  {
    console.log('sortList1', sortList);
  }

  return (
    <SafeAreaView style={styles.container}>
      <View
        style={{
          flexDirection: 'row',
          padding: 10,
          justifyContent: 'center',
          alignItems: 'center',
          marginBottom: 10,
          paddingHorizontal: 30,
          backgroundColor: inputShow ? 'white' : '#1974D2',
        }}>
        <TouchableWithoutFeedback
          style={{height: 30, width: 30}}
          onPress={() => {
            setInputShow(false);
            setContactSearch('');
          }}>
          <Image
            source={require('../screens/CountryFlag/ic_arrow_back.png')}
            style={{
              width: 30,
              height: 30,
              tintColor: 'black',
              marginRight: 5,
            }}
          />
        </TouchableWithoutFeedback>
        {inputShow ? (
          <TextInput
            placeholder="Search contacts"
            value={contactSearch}
            // onKeyPress={search}
            autoFocus
            onChangeText={setContactSearch}
            style={styles.input}
          />
        ) : (
          <Text
            style={{
              width: '85%',
              // textAlign: 'center',
              paddingHorizontal: 20,
              paddingTop: 7,
              height: 40,
              fontWeight: 'bold',
              fontSize: 18,
            }}>
            Contacts
          </Text>
        )}
        {!inputShow && (
          <TouchableWithoutFeedback
            style={{paddingHorizontal: 10}}
            onPress={() => {
              setInputShow(true);
            }}>
            <Image
              source={require('../screens/CountryFlag/search.png')}
              style={{width: 15, height: 15, resizeMode: 'cover'}}
            />
          </TouchableWithoutFeedback>
        )}
      </View>
      {/* <FlatList
        style={{paddingRight: 20, marginBottom: 40}}
        data={contact}
        renderItem={contact => (
          <>
          
            <TouchableWithoutFeedback
              style={{
                paddingHorizontal: 20,
                flexDirection: 'row',
                paddingVertical: 10,
              }}
              onPress={() => {}}>
              {contact.item.displayName[0] == '+' ? (
                <View
                  style={{
                    width: 40,
                    height: 40,
                    paddingVertical: 10,
                    borderRadius: 20,
                    backgroundColor: contact.item.color,
                  }}>
                  <Image
                    source={require('../assets/Images/ic_profile.png')}
                    style={{
                      width: 20,
                      height: 20,
                      alignSelf: 'center',
                    }}
                  />
                </View>
              ) : (
                <Text
                  style={{
                    width: 40,
                    height: 40,
                    borderRadius: 20,
                    backgroundColor: contact.item.color,
                    textAlign: 'center',
                    textAlignVertical: 'center',
                    color: 'white',
                    fontSize: 15,
                  }}>
                  {contact.item.displayName[0]}
                </Text>
              )}
              <View
                style={{
                  flexDirection: 'column',
                  paddingHorizontal: 10,
                  display: 'flex',
                  justifyContent: 'center',
                }}>
                {!contact.item.displayName.includes(91) && (
                  <Text>{contact.item.displayName}</Text>
                )}
                <Text>{contact.item.phoneNumbers[0].number}</Text>
              </View>

              <Text>{contact.item.phoneNumber}</Text>
            </TouchableWithoutFeedback>
          </>
        )}
      /> */}
      {console.log('Line 5', sortList)}
      {/* <FlatList
          data={sortList}
          style={{paddingBottom:40}}
          renderItem={sortList => (
            <>
              <TouchableWithoutFeedback
                onPress={() => {
                  {console.log(sortList.index);
                  }
                  // sortList.index;
                }}>
                <Text> {sortList.item.title}</Text>
              </TouchableWithoutFeedback>
            </>
          )}
        /> */}

      <SectionList
        // style={{ backgroundColor: 'red'}}
        ref={ref}
        style={{
          paddingRight: 20,
          // height: 200,
          // width: '70%',
          position: 'relative',
          // marginBottom: 60,
        }}
        showsVerticalScrollIndicator={false}
        sections={sortList}
        keyExtractor={(item, index) => item + index}
        stickySectionHeadersEnabled
        renderItem={({item}) => (
          <>
            <TouchableWithoutFeedback
              style={{
                paddingHorizontal: 20,
                flexDirection: 'row',
                paddingVertical: 10,
              }}>
              {item.displayName[0] == '+' ? (
                <View
                  style={{
                    width: 40,
                    height: 40,
                    paddingVertical: 10,
                    borderRadius: 20,
                    backgroundColor: item.color,
                  }}>
                  <Image
                    source={require('../assets/Images/ic_profile.png')}
                    style={{
                      width: 20,
                      height: 20,
                      alignSelf: 'center',
                    }}
                  />
                </View>
              ) : (
                <Text
                  style={{
                    width: 40,
                    height: 40,
                    borderRadius: 20,
                    backgroundColor: item.color,
                    textAlign: 'center',
                    textAlignVertical: 'center',
                    color: 'white',
                    fontSize: 15,
                  }}>
                  {item.displayName[0]}
                </Text>
              )}
              <View
                style={{
                  flexDirection: 'column',
                  paddingHorizontal: 10,
                  display: 'flex',
                  justifyContent: 'center',
                }}>
                {!item.displayName.includes(91) && (
                  <Text>{item.displayName}</Text>
                )}
                <Text>{item.phoneNumbers[0].number}</Text>
              </View>

              <Text>{item.phoneNumber}</Text>
            </TouchableWithoutFeedback>
          </>
        )}
        renderSectionHeader={({section: {title}}) => (
          <View>
            {!inputShow && (
              <Text
                style={{
                  paddingHorizontal: 20,
                  height: 20,
                  backgroundColor: '#ecf0f1',
                  // backgroundColor:'white'
                }}>
                {title.includes('+') ? '#' : title}
              </Text>
            )}
          </View>
        )}
      />

      {!inputShow && (
        <FlatList
          data={sortList}
          style={styles.selectItem}
          // style={{ position: 'absolute',right: 5,top: 100,borderRadius:10,backgroundColor:'#DEE4E7',paddingVertical:10, paddingHorizontal:5}}
          renderItem={sortList => (
            <>
              <TouchableWithoutFeedback
                onPress={() => {
                  ref?.current?.scrollToLocation({
                    sectionIndex: sortList.index,
                    itemIndex: 0,
                    animated: true,
                  });
                  setSelectIndex(sortList.index);
                }}>
                {selectIndex == sortList.index && (
                  <Text
                    style={{
                      //  right: 5,
                      backgroundColor: '#DEE4E7',
                      width: 20,
                      height: 20,
                      //  borderRadius: 10,
                      //  top:16,
                      position: 'relative',
                    }}>
                    {sortList.item.title}
                  </Text>
                )}
                {console.log('setSelectIndex', selectIndex)}

                <Text
                  style={[
                    {
                      fontSize: 10,
                      textAlign: 'center',
                    },
                    selectIndex == sortList.index && styles.listColor,
                  ]}>
                  {sortList.item.title.includes('+')
                    ? '#'
                    : sortList.item.title}
                </Text>
              </TouchableWithoutFeedback>
            </>
          )}
        />
      )}
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    //   paddingTop: StatusBar.currentHeight,
    backgroundColor: '#ecf0f1',
    // padding: 10,
  },
  item: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  input: {
    backgroundColor: 'white',
    marginHorizontal: 5,
    paddingHorizontal: 20,
    height: 40,
    width: '92%',
  },
  selectItem: {
    width: 20,
    position: 'absolute',
    right: 5,
    top: 100,
    backgroundColor: '#DEE4E7',
    borderRadius: 10,
    paddingVertical: 5,
    paddingHorizontal: 5,
  },
  listColor: {
    color: 'blue'
  },
});

export default ContactsPicker;
