import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {NavigationContainer} from '@react-navigation/native';
import Home from './Home';
import Game from './Game';
import Demo from './Demo';
import CountryPicker from './CountryPicker';
import ObjectMethods from './ObjectMethods';
import ContactsPicker from './ContactsPicker';

const Stack = createStackNavigator();

export const MyNavigator = (): React.ReactElement => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="ContactsPicker" screenOptions={{headerShown:false}}>
        <Stack.Screen component={Home} name="Home" />
        <Stack.Screen component={Game} name="Game"/>
        <Stack.Screen component={Demo} name="Demo"/>
        <Stack.Screen component={CountryPicker} name="CountryPicker"/>
        <Stack.Screen component={ObjectMethods} name="ObjectMethods"/>
        <Stack.Screen component={ContactsPicker} name="ContactsPicker"/>
      </Stack.Navigator>
    </NavigationContainer>
  );
};
