import React, {useState} from 'react';
import {useEffect} from 'react';
import {View, StyleSheet, Text, Button, ToastAndroid} from 'react-native';
import {TouchableWithoutFeedback} from 'react-native-gesture-handler';

const Game: React.FC = () => {
  const [boxArray, setBoxArray] = useState([
    ['', '', ''],
    ['', '', ''],
    ['', '', ''],
  ]);
  const [box, setBox] = useState([
    [0, 1, 2],
    [0, 1, 2],
    [0, 1, 2],
  ]);
  const [verBox, setVerBox] = useState([0, 1, 2]);
  const temp = [...boxArray];
  const [value, setValue] = useState(true);
  const [btnshow, setBtnShow] = useState(false);

  useEffect(() => {
    check();
  }, [boxArray]);

  const check = () => {
    if (
      (boxArray[0][0] == 'O' &&
        boxArray[0][1] == 'O' &&
        boxArray[0][2] == 'O') ||
      (boxArray[1][0] == 'O' &&
        boxArray[1][1] == 'O' &&
        boxArray[1][2] == 'O') ||
      (boxArray[2][0] == 'O' &&
        boxArray[2][1] == 'O' &&
        boxArray[2][2] == 'O') ||
      (boxArray[0][0] == 'O' &&
        boxArray[1][0] == 'O' &&
        boxArray[2][0] == 'O') ||
      (boxArray[0][1] == 'O' &&
        boxArray[1][1] == 'O' &&
        boxArray[2][1] == 'O') ||
      (boxArray[0][2] == 'O' &&
        boxArray[1][2] == 'O' &&
        boxArray[2][2] == 'O') ||
      (boxArray[0][0] == 'O' &&
        boxArray[1][1] == 'O' &&
        boxArray[2][2] == 'O') ||
      (boxArray[0][2] == 'O' && boxArray[1][1] == 'O' && boxArray[2][0] == 'O')
    ) {
      ToastAndroid.show('O Win', ToastAndroid.SHORT);
      setBtnShow(true);
      return true;
    } else if (
      (boxArray[0][0] == 'X' &&
        boxArray[0][1] == 'X' &&
        boxArray[0][2] == 'X') ||
      (boxArray[1][0] == 'X' &&
        boxArray[1][1] == 'X' &&
        boxArray[1][2] == 'X') ||
      (boxArray[2][0] == 'X' &&
        boxArray[2][1] == 'X' &&
        boxArray[2][2] == 'X') ||
      (boxArray[0][0] == 'X' &&
        boxArray[1][0] == 'X' &&
        boxArray[2][0] == 'X') ||
      (boxArray[0][1] == 'X' &&
        boxArray[1][1] == 'X' &&
        boxArray[2][1] == 'X') ||
      (boxArray[0][2] == 'X' &&
        boxArray[1][2] == 'X' &&
        boxArray[2][2] == 'X') ||
      (boxArray[0][0] == 'X' &&
        boxArray[1][1] == 'X' &&
        boxArray[2][2] == 'X') ||
      (boxArray[0][2] == 'X' && boxArray[1][1] == 'X' && boxArray[2][0] == 'X')
    ) {
      // console.log('vhcvhchcvhc');
      ToastAndroid.show('X Win', ToastAndroid.SHORT);
      setBtnShow(true);
      return true;
    } else if (
      !(
        boxArray[0].includes('') ||
        boxArray[1].includes('') ||
        boxArray[2].includes('')
      )
    ) {
      ToastAndroid.show('Match Draw', ToastAndroid.SHORT);
      setBtnShow(true);
      return true;
    }
    return false;
    /*  (boxArray[0][0] == 'O' &&
      boxArray[0][1] == 'O' &&
      boxArray[0][2] == 'O' &&
      setWinMsg('O Win')) ||
    (boxArray[1][0] == 'O' &&
      boxArray[1][1] == 'O' &&
      boxArray[1][2] == 'O' &&
      setWinMsg('O Win')) ||
    (boxArray[2][0] == 'O' &&
      boxArray[2][1] == 'O' &&
      boxArray[2][2] == 'O' &&
      setWinMsg('O Win')) ||
    (boxArray[0][0] == 'O' &&
      boxArray[1][0] == 'O' &&
      boxArray[2][0] == 'O' &&
      setWinMsg('O Win')) ||
    (boxArray[0][1] == 'O' &&
      boxArray[1][1] == 'O' &&
      boxArray[2][1] == 'O' &&
      setWinMsg('O Win')) ||
    (boxArray[0][2] == 'O' &&
      boxArray[1][2] == 'O' &&
      boxArray[2][2] == 'O' &&
      setWinMsg('O Win')) ||
    (boxArray[0][0] == 'O' &&
      boxArray[1][1] == 'O' &&
      boxArray[2][2] == 'O' &&
      setWinMsg('O Win')) ||
    (boxArray[0][2] == 'O' &&
      boxArray[1][1] == 'O' &&
      boxArray[2][0] == 'O' &&
      setWinMsg('O Win')) ||
    (boxArray[0][0] == 'X' &&
      boxArray[0][1] == 'X' &&
      boxArray[0][2] == 'X' &&
      setWinMsg('X Win')) ||
    (boxArray[1][0] == 'X' &&
      boxArray[1][1] == 'X' &&
      boxArray[1][2] == 'X' &&
      setWinMsg('X Win')) ||
    (boxArray[2][0] == 'X' &&
      boxArray[2][1] == 'X' &&
      boxArray[2][2] == 'X' &&
      setWinMsg('X Win')) ||
    (boxArray[0][0] == 'X' &&
      boxArray[1][0] == 'X' &&
      boxArray[2][0] == 'X' &&
      setWinMsg('X Win')) ||
    (boxArray[0][1] == 'X' &&
      boxArray[1][1] == 'X' &&
      boxArray[2][1] == 'X' &&
      setWinMsg('X Win')) ||
    (boxArray[0][2] == 'X' &&
      boxArray[1][2] == 'X' &&
      boxArray[2][2] == 'X' &&
      setWinMsg('X Win')) ||
    (boxArray[0][0] == 'X' &&
      boxArray[1][1] == 'X' &&
      boxArray[2][2] == 'X' &&
      setWinMsg('X Win')) ||
    (boxArray[0][2] == 'X' &&
      boxArray[1][1] == 'X' &&
      boxArray[2][0] == 'X' &&
      setWinMsg('X Win'))
      ? null
      : boxArray[0].includes('') ||
        boxArray[1].includes('') ||
        boxArray[2].includes('')
      ? null
      : setWinMsg('Match Draw'); */
  };

  /*  const twoPerson = () => {
    if (value) {
      temp[index][indexs] = 'O';
      setBoxArray(temp);
      setValue(false);
    } else {
      temp[index][indexs] = 'X';
      setBoxArray(temp);
      setValue(false);
    }
  }; */

  const resetData = () => {
    boxArray.map((item, index) => {
      boxArray[index].map((items, indexs) => {
        temp[index][indexs] = '';
        setBoxArray(temp);
      });
    });
    setVerBox([0, 1, 2]);
    setBox([
      [0, 1, 2],
      [0, 1, 2],
      [0, 1, 2],
    ]);
  };

  const position = () => {
    if (!(verBox == [])) {
      let index = verBox[Math.floor(Math.random() * verBox.length)];
      console.log('length', box[index]);
      // if(box[index])
      if (box[index] != undefined) {
        let indexs = box[index][Math.floor(Math.random() * box[index].length)];
        console.log('verBox.length', verBox.length > 0);
        // if (verBox.length > 1) {
        // if(box[index][indexs]>0)
        if (!(boxArray[index] === [])) {
          if (!boxArray[index][indexs].includes('O')) {
            console.log('X Prints b', temp[index]);
            console.log(
              'temp[index][indexs].includes() O',
              boxArray[index][indexs].includes('O'),
            );
            console.log(
              'temp[index][indexs].includes() X',
              boxArray[index][indexs].includes('X'),
            );
            console.log(
              'temp[index][indexs].includes()',
              boxArray[index][indexs].includes(''),
            );
            if (
              boxArray[index][indexs].includes('') &&
              !boxArray[index][indexs].includes('X')
            ) {
              temp[index][indexs] = 'X';
              setBoxArray(temp);
              box[index].splice(indexs, 1);
              console.log('position', box[index]);
              if (!boxArray[index].includes('')) {
                // box.splice(index, 1);
                verBox.splice(index, 1);
                console.log('verBox', verBox);
              }
            }
          } else if (boxArray[index][indexs].includes('O')) {
            index = verBox[Math.floor(Math.random() * verBox.length)];
            console.log('box[index].length', box[index].length);
            indexs = box[index][Math.floor(Math.random() * box[index].length)];
            console.log('X indexs', index);
            if (boxArray[index][indexs].includes('O')) {
              console.log('X box[index].length', index);
              if (indexs != 2) {
                indexs = indexs + 1;
              }
              console.log('X indexs', indexs);
              temp[index][indexs] = 'X';
              setBoxArray(temp);
              box[index].splice(indexs, 1);
              if (!boxArray[index].includes('')) {
                // box.splice(index, 1);
                verBox.splice(index, 1);
                console.log('verBox', verBox);
              }
              console.log('position O', box[index]);
            } else if (!boxArray[index][indexs].includes('O')) {
              temp[index][indexs] = 'X';
              setBoxArray(temp);
              box[index].splice(indexs, 1);
              if (!boxArray[index].includes('')) {
                // box.splice(index, 1);
                verBox.splice(index, 1);
                console.log('verBox', verBox);
              }
              console.log('position', box);
            }
          } else if (boxArray[index][indexs].includes('X')) {
            console.log('X Prints', temp[index]);
            index = verBox[Math.floor(Math.random() * verBox.length)];
            indexs = box[index][Math.floor(Math.random() * box[index].length)];
            console.log('X box[index].length', box[index].length);
            console.log('X indexs', index);
            if (boxArray[index][indexs].includes('O')) {
              console.log('X box[index].length', index);
              console.log('X indexs', verBox);
              if (indexs != 2) {
                indexs = indexs + 1;
              }
              temp[index][indexs] = 'X';
              setBoxArray(temp);
              box[index].splice(indexs, 1);
              if (!boxArray[index].includes('')) {
                // box.splice(index, 1);
                verBox.splice(index, 1);
                console.log('verBox', verBox);
              }
              console.log('position O', box[index]);
            } else if (!boxArray[index][indexs].includes('O')) {
              temp[index][indexs] = 'X';
              setBoxArray(temp);
              box[index].splice(indexs, 1);
              if (!boxArray[index].includes('')) {
                // box.splice(index, 1);
                verBox.splice(index, 1);
                console.log('verBox', verBox);
              }
              console.log('position', box);
            }
            // }

            /*  else if (temp[index][indexs].includes('X')) {
          indexs = box[index][Math.floor(Math.random() * box[index].length)];
          temp[index][indexs] = 'X';
          setBoxArray(temp);
          box[index].splice(indexs, 1);
          console.log('position', box[index]);
        } */
            console.log(
              'value',
              // temp[index][Math.floor(Math.random() * box[index].length)].includes(''),
            );
          }
        }
        console.log('X Length', box);
        // setValue(false);
        // box[index].splice(indexs, 1);
      } else if (box[index] == undefined) {
        index = verBox[Math.floor(Math.random() * verBox.length)];
        console.log('verBox Undefined', verBox);
        console.log('verBox Undefined', index);
        console.log('verBox Undefined', box);
        console.log('verBox Undefined', box[index]);

        let indexs = box[index][Math.floor(Math.random() * box[index].length)];
        if (boxArray[index][indexs].includes('')) {
          /*     index = verBox[Math.floor(Math.random() * verBox.length)];
          indexs = box[index][Math.floor(Math.random() * box[index].length)];
          if (boxArray[index][indexs].includes('')) { */
          temp[index][indexs] = 'X';
          setBoxArray(temp);
          box[index].splice(indexs, 1);
          console.log('position Undefined', box[index]);
          if (!temp[index].includes('')) {
            // box.splice(index, 1);
            verBox.splice(index, 1);
            console.log('verBox Undefined', verBox);
          }
        }
        // }
        /*  else if (box[index] != undefined) {
          let indexs =box[index][Math.floor(Math.random() * box[index].length)];
            console.log('verBox Undefined', box);
            console.log('verBox Undefined', box[index]);
          if (boxArray[index][indexs].includes('')) {
            temp[index][indexs] = 'X';
            setBoxArray(temp);
            box[index].splice(indexs, 1);
            console.log('position Undefined', box[index]);
            if (!temp[index].includes('')) {
              // box.splice(index, 1);
              verBox.splice(index, 1);
              console.log('verBox Undefined', verBox);
            }
          }
        } */
      }
    }
  };

  return (
    <View>
      <View style={styles.box}>
        {boxArray.map((item, index) => {
          {
            // console.log(boxArray);
          }
          return (
            <View style={{flexDirection: 'row'}}>
              {boxArray[index].map((items, indexs) => {
                {
                  // console.log('Index', boxArray[index]);
                }
                return (
                  <TouchableWithoutFeedback
                    disabled={btnshow || temp[index][indexs]}
                    onPress={() => {
                      // if (value) {
                      temp[index][indexs] = 'O';
                      setBoxArray(temp);
                      if (box[index] != undefined) {
                      }
                      box[index].splice(indexs, 1);
                      if (!boxArray[index].includes('')) {
                        box.splice(index, 1);
                        verBox.splice(index, 1);
                        console.log('verBox', verBox);
                      }
                      if (!check()) {
                        position();
                      }
                      // , setValue(false);

                      /*   if (!boxArray[index].includes('')) {
                        box.splice(index, 1);
                        console.log('verBox',  verBox.splice(index, 1));
                        verBox.splice(index, 1);
                        console.log('verBox', box.splice(index, 1));
                        // console.log('verbox', verBox);
                      } */
                      // console.log('btnShow', btnshow);
                      // console.log('X Print', box[index]);
                    }}
                    style={styles.boxs}>
                    <Text style={{color: 'white'}}>{[items]}</Text>
                  </TouchableWithoutFeedback>
                );
              })}
            </View>
          );
        })}
      </View>
      {/* {console.log(temp[0][Math.floor(Math.random() * temp[0].length)])} */}
      <View style={{marginHorizontal: 150}}>
        {btnshow && (
          <Button
            title="Reset"
            onPress={() => {
              resetData();
              setBtnShow(false);
            }}
          />
        )}
      </View>
    </View>
  );
};
export default Game;
const styles = StyleSheet.create({
  box: {
    height: 150,
    backgroundColor: 'grey',
    margin: 20,
  },
  boxs: {
    // flex: 1,
    width: 124,
    borderLeftWidth: 1,
    height: 50,
    borderBottomWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
