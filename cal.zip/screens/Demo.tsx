import React, {useState} from 'react';
import {useEffect} from 'react';
import {View, StyleSheet, Text, Button, ToastAndroid} from 'react-native';
import {TouchableWithoutFeedback} from 'react-native-gesture-handler';

const Demo: React.FC = () => {
  const [boxArray, setBoxArray] = useState(['','','','','','','','']);
  const [btnshow, setBtnShow] = useState(false);
  const resetData = () => {
    boxArray.map((item, index) => {
      boxArray[index] = '';
    });
  };
  return (
    <View>
      <View style={styles.box}>
        {boxArray.map((item, index) => {
          {
            console.log(boxArray);
          }
          return (
            <View style={{flexDirection: 'row'}}>
              <TouchableWithoutFeedback
                disabled={boxArray[index] || btnshow}
                onPress={() => {
                 const temp=boxArray[index]='O'
setBoxArray(temp)
                }}
                style={styles.boxs}>
                <Text style={{color: 'white'}}>{[item]}</Text>
              </TouchableWithoutFeedback>
            </View>
              );
        }
        )}
      </View>
      <View style={{marginHorizontal: 150}}>
        {btnshow && (
          <Button
            title="Reset"
            onPress={() => {
              resetData();
              setBtnShow(false);
            }}
          />
        )}
      </View>
    </View>
  );
};
export default Demo;
const styles = StyleSheet.create({
  box: {
    height: 150,
    backgroundColor: 'grey',
    margin: 20,
  },
  boxs: {
    // flex: 1,
    width: 124,
    borderLeftWidth: 1,
    height: 50,
    borderBottomWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
