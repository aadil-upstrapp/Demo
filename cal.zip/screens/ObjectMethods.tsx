import React, {useState} from 'react';
import {Text, View, StyleSheet} from 'react-native';
const ObjectMethods: React.FC = () => {
  const obj = [
    {id: 1, name: 'aadil'},
    {id: 2, name: 'arkan'},
    {id: 3, name: 'musef'},

];
const [data,setData]=useState('');
const search=()=>{
    obj.map((item,index)=>{
        setData(item)
    })
}
  return (
    <View>
      <Text>{data}</Text>
    </View>
  );
};
export default ObjectMethods;
