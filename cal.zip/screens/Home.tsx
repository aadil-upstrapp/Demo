import React from 'react';
import {useState} from 'react';
import {Text, View, StyleSheet} from 'react-native';
import {TouchableWithoutFeedback} from 'react-native-gesture-handler';

const Home: React.FC = () => {
  const [number, setNumber] = useState('');
  const [secoundNumber, setSecoundNumber] = useState('');
  const [operations, setOperations] = useState('');
  const [result, setResult] = useState('');

  const btnClick = i => {
    operations ? setSecoundNumber(secoundNumber + i) : setNumber(number + i);
  };

  const sum = () => {
    if (operations == '+') {
      setResult(parseFloat(result || number) + parseFloat(secoundNumber));
      clear();
    } else if (operations == '-') {
      setResult(parseFloat(result || number) - parseFloat(secoundNumber));
      clear();
    } else if (operations == '*') {
      setResult(parseFloat(result || number) * parseFloat(secoundNumber));
      clear();
    } else if (operations == '/') {
      setResult(parseFloat(result || number) / parseFloat(secoundNumber));
      clear();
    }
  };

  const clearBtn = () => {
    setNumber('');
    setSecoundNumber('');
    setOperations('');
    setResult('');
  };
  const clear = () => {
    setNumber('');
    setSecoundNumber('');
    setOperations('');
  };

  return (
    <View style={styles.main}>
      <View
        style={{
          alignItems: 'flex-end',
          paddingVertical: 20,
          paddingEnd: 10,
        }}>
        {result ? (
          <Text
            style={{
              fontSize: 20,
            }}>{`${result} ${operations} ${secoundNumber}`}</Text>
        ) : (
          <Text
            style={{
              fontSize: 20,
            }}>{`${number} ${operations} ${secoundNumber}`}</Text>
        )}
      </View>
      <View style={{flexDirection: 'row', flexWrap: 'wrap'}}>
        <TouchableWithoutFeedback
          style={styles.button}
          onPress={() => {
            clearBtn();
          }}>
          <Text>C</Text>
        </TouchableWithoutFeedback>
        <TouchableWithoutFeedback
          style={styles.button}
          onPress={() => {
            operations
              ? secoundNumber.length > 0
                ? setSecoundNumber(secoundNumber.slice(0, -1))
                : setOperations('')
              : setNumber(number.slice(0, -1));
          }}>
          <Text>CE</Text>
        </TouchableWithoutFeedback>
        <TouchableWithoutFeedback
          style={styles.button}
          onPress={() => {
            setOperations('/');
          }}>
          <Text>/</Text>
        </TouchableWithoutFeedback>
        <TouchableWithoutFeedback
          style={styles.button}
          onPress={() => {
            setOperations('%');
          }}>
          <Text>%</Text>
        </TouchableWithoutFeedback>
        <TouchableWithoutFeedback
          style={styles.button}
          onPress={() => {
            btnClick(1);
          }}>
          <Text>1</Text>
        </TouchableWithoutFeedback>
        <TouchableWithoutFeedback
          style={styles.button}
          onPress={() => {
            btnClick(2);
          }}>
          <Text>2</Text>
        </TouchableWithoutFeedback>
        <TouchableWithoutFeedback
          style={styles.button}
          onPress={() => {
            btnClick(3);
          }}>
          <Text>3</Text>
        </TouchableWithoutFeedback>
        <TouchableWithoutFeedback
          style={styles.button}
          onPress={() => {
            setOperations('+');
          }}>
          <Text>+</Text>
        </TouchableWithoutFeedback>
        <TouchableWithoutFeedback
          style={styles.button}
          onPress={() => {
            btnClick(4);
          }}>
          <Text>4</Text>
        </TouchableWithoutFeedback>
        <TouchableWithoutFeedback
          style={styles.button}
          onPress={() => {
            btnClick(5);
          }}>
          <Text>5</Text>
        </TouchableWithoutFeedback>
        <TouchableWithoutFeedback
          style={styles.button}
          onPress={() => {
            btnClick(6);
          }}>
          <Text>6</Text>
        </TouchableWithoutFeedback>
        <TouchableWithoutFeedback
          onPress={() => {
            setOperations('-');
          }}
          style={styles.button}>
          <Text>-</Text>
        </TouchableWithoutFeedback>
        <TouchableWithoutFeedback
          style={styles.button}
          onPress={() => {
            btnClick(7);
          }}>
          <Text>7</Text>
        </TouchableWithoutFeedback>
        <TouchableWithoutFeedback
          style={styles.button}
          onPress={() => {
            btnClick(8);
          }}>
          <Text>8</Text>
        </TouchableWithoutFeedback>
        <TouchableWithoutFeedback
          style={styles.button}
          onPress={() => {
            btnClick(9);
          }}>
          <Text>9</Text>
        </TouchableWithoutFeedback>
        <TouchableWithoutFeedback
          style={styles.button}
          onPress={() => {
            setOperations('*');
          }}>
          <Text>*</Text>
        </TouchableWithoutFeedback>
        <TouchableWithoutFeedback
          style={styles.button}
          onPress={() => {
            operations?
            secoundNumber.includes('.') ? btnClick('') : btnClick('.')
            :number.includes('.') ? btnClick('') : btnClick('.')
          }}>
          <Text>.</Text>
        </TouchableWithoutFeedback>
        <TouchableWithoutFeedback
          style={styles.button}
          onPress={() => {
            btnClick(0);
          }}>
          <Text>0</Text>
        </TouchableWithoutFeedback>
        <TouchableWithoutFeedback
          style={styles.button}
          onPress={() => {
            operations
              ? secoundNumber.includes('-')
                ? setSecoundNumber(secoundNumber.replace('-', ''))
                : setSecoundNumber('-' + secoundNumber)
              : number.includes('-')
              ? setNumber(number.replace('-', ''))
              : setNumber('-' + number);
          }}>
          <Text>+/-</Text>
        </TouchableWithoutFeedback>
        <TouchableWithoutFeedback
          style={styles.button}
          onPress={() => {
            sum(operations);
          }}>
          <Text>=</Text>
        </TouchableWithoutFeedback>
      </View>
    </View>
  );
};
export default Home;
const styles = StyleSheet.create({
  main: {
    flex: 1,
    padding: 25,
    marginTop: 100,
  },
  button: {
    justifyContent: 'center',
    alignItems: 'center',
    width: 70,
    height: 50,
    marginVertical: 10,
    marginStart: 10,
    marginEnd: 10,
    backgroundColor: 'gray',
    borderRadius: 10,
  },
});
